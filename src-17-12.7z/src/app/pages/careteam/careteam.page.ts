import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-careteam',
  templateUrl: './careteam.page.html',
  styleUrls: ['./careteam.page.scss'],
})
export class CareteamPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
