export interface MenuLink {
    title: string;
    linkHref: string;
    icon: string;
}