export interface patientProgram {
    PatientId: number,
    ProgramDate: any,
    ProgramId: number,
    ProgramName: string,
}